/*! grafana - v3.0.0-pre1 - 2016-01-03
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["angular","lodash"],function(a,b){"use strict";var c=a.module("grafana.controllers");c.controller("CloudWatchQueryCtrl",["$scope",function(c){c.init=function(){c.aliasSyntax="{{metric}} {{stat}} {{namespace}} {{region}} {{<dimension name>}}"},c.refreshMetricData=function(){b.isEqual(c.oldTarget,c.target)||(c.oldTarget=a.copy(c.target),c.get_data())},c.init()}])});