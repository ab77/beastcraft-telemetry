/*! grafana - v3.0.0-pre1 - 2016-01-03
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["angular","lodash","app/core/config"],function(a,b,c){"use strict";var d=a.module("grafana.controllers");d.controller("PluginEditCtrl",["$scope","pluginSrv","$routeParams",function(a,d,e){a.init=function(){a.current={},a.getPlugins()},a.getPlugins=function(){d.get(e.type).then(function(c){a.current=b.clone(c)})},a.update=function(){a._update()},a._update=function(){d.update(a.current).then(function(){window.location.href=c.appSubUrl+"plugins"})},a.init()}])});