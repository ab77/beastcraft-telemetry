declare module "test/specs/helpers" {
  let helpers: any;
  export default helpers;
}


