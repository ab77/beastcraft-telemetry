/*! grafana - v3.0.0-pre1 - 2016-01-03
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["angular","app/core/config"],function(a,b){"use strict";var c=a.module("grafana.controllers");c.controller("PluginsCtrl",["$scope","$location","pluginSrv",function(a,c,d){a.init=function(){a.plugins={},a.getPlugins()},a.getPlugins=function(){d.getAll().then(function(b){console.log(b),a.plugins=b})},a.update=function(a){d.update(a).then(function(){window.location.href=b.appSubUrl+c.path()})},a.init()}])});