/// <reference path="../../../../../public/app/headers/common.d.ts" />
export declare class TablePanelCtrl {
    /** @ngInject */
    constructor($scope: any, $rootScope: any, $q: any, panelSrv: any, panelHelper: any, annotationsSrv: any);
}
