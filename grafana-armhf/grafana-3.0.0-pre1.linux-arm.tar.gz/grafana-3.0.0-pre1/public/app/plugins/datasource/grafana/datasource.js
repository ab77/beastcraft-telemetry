/*! grafana - v3.0.0-pre1 - 2016-01-03
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["angular"],function(a){"use strict";var b=a.module("grafana.services");b.factory("GrafanaDatasource",["$q","backendSrv",function(a,b){function c(){}return c.prototype.query=function(a){return b.get("/api/metrics/test",{from:a.range.from.valueOf(),to:a.range.to.valueOf(),maxDataPoints:a.maxDataPoints})},c.prototype.metricFindQuery=function(){return a.when([])},c}])});