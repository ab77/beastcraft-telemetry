///<reference path="../headers/common.d.ts" />

import angular from 'angular';
export default angular.module('grafana.core', ['ngRoute']);
