/// <reference path="../../../../public/app/headers/common.d.ts" />
declare var grafanaCtrl: {};
export default grafanaCtrl;
